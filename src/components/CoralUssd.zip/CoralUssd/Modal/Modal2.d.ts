/// <reference types="react" />
import "../assets/css/modal.css";
declare const Modal2: ({ children }: {
    children: any;
}) => JSX.Element;
export default Modal2;
