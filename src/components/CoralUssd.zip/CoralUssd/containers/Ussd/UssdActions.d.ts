import { FC } from "react";
import "../../assets/css/button.css";
declare const UssdActions: FC<any>;
export default UssdActions;
