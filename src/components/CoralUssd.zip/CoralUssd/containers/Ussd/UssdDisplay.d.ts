import { FC } from "react";
import "../../assets/css/display.css";
declare const UssdDisplay: FC<any>;
export default UssdDisplay;
