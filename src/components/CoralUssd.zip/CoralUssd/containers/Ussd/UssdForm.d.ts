import { FC } from "react";
import "../../assets/css/ussdform.css";
declare const UssdForm: FC<any>;
export default UssdForm;
