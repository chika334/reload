import { FC } from "react";
declare const UssdHeader: FC<any>;
export default UssdHeader;
