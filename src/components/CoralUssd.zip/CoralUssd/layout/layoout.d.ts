import { FC } from "react";
import "../assets/css/layout.css";
declare const Layout: FC<any>;
export default Layout;
