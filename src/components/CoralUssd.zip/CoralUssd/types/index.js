export * from "./interface";
//# sourceMappingURL=index.js.map